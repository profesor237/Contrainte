#include <iostream>
#include "fonction.h"


void fonction(int n, int p, double tab[N][N], double tab2[N])
{
    if(n == p-2){
        int i=0,r=0;
        double cal,coef; // pour calculer la valeur du changement de variable approprier.
        std::string si ="sin", plus = " + ", moins = " - ", carre = "^2", var="y", sin = "sin(", par1 = "(",par2=")", cal_, coef_;
        Matrice m;
        m.saisie(n,tab);
        std::string B[n];
        std::string X[n];
        
        
        for(int i=0;i<n;i++){
            r = i + 1;
            //je converti r en string                
            std::stringstream ss;
            ss << r ;
            std::string r_ = ss.str();
            
            if(tab[i][p-2] == 0.0001 && tab[i][p-1] == 0.0001){  
                B[i] = var + r_ + carre; 
            }
            else{
                
                if(tab[i][p-2] == 0.0002 && tab[i][p-1] == 0.0002){
                    B[i] = sin + var + r_ + par2; 
                }
                
                if(tab[i][p-2] != 0.0001 && tab[i][p-2] != 0.0002){
                    coef = tab[i][p-2];
                    cal = tab[i][p-1] - tab[i][p-2];
                    
                    // pour coef                    
                    std::stringstream st;
                    st << coef;
                    std::string coef_ = st.str();
                    
                    // pour cal
                    std::stringstream ts;
                    ts << cal ;
                    std::string cal_ = ts.str();
                    if(cal > 0){ 
                        B[i] = par1 + coef_ + par2 + plus + cal_ + par1 + si + var + r_ + par2 + carre;  
                    }
                    else {
                        
                        if(cal < 0){
                            B[i] = par1 + coef_ + par2 + plus + cal_ + par1 + si + var + r_ + par2 + carre;
                        }
                        
                        if(cal == 0) B[i] = par1 + coef_ + par2;
                    }
            }
            
        }
            

        }
       
        m.gaussifier(B,X,p-2);
        m.afficher(B,X,p-2,tab2,0);
    }
    else{
        if(n>p-2){
            
        int i=0,r=0;
        double cal,coef; // pour calculer la valeur du changement de variable approprier.
        std::string si ="sin", plus = " + ", moins = " - ", carre = "^2", var="y", sin = "sin(", par1 = "(",par2=")", cal_, coef_;
        Matrice m;
        m.saisie(p-2,tab);
        std::string B[p-2];
        std::string X[p-2];
        
        
        for(int i=0;i<p-2;i++){
            r = i + 1;
            //je converti r en string                
            std::stringstream ss;
            ss << r ;
            std::string r_ = ss.str();
            
            if(tab[i][p-2] == 0.0001 && tab[i][p-1] == 0.0001){  
                B[i] = var + r_ + carre; 
            }
            else{
                
                if(tab[i][p-2] == 0.0002 && tab[i][p-1] == 0.0002){
                    B[i] = sin + var + r_ + par2; 
                }
                
                if(tab[i][p-2] != 0.0001 && tab[i][p-2] != 0.0002){
                    coef = tab[i][p-2];
                    cal = tab[i][p-1] - tab[i][p-2];
                    
                    // pour coef                    
                    std::stringstream st;
                    st << coef;
                    std::string coef_ = st.str();
                    
                    // pour cal
                    std::stringstream ts;
                    ts << cal ;
                    std::string cal_ = ts.str();
                    if(cal > 0){ 
                        B[i] = par1 + coef_ + par2 + plus + cal_ + par1 + si + var + r_ + par2 + carre;  
                    }
                    else {
                        
                        if(cal < 0){
                            B[i] = par1 + coef_ + par2 + plus + cal_ + par1 + si + var + r_ + par2 + carre;
                        }
                        
                        if(cal == 0) B[i] = par1 + coef_ + par2;
                    }
            }
            
        }
            

        }
       
        m.gaussifier(B,X,p-2);
        m.afficher(B,X,p-2,tab2,n-(p-2));
        
       
            
        }
    }
         
}
