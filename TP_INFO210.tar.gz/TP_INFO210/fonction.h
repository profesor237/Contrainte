
#ifndef FONCTION_H
#define FONCTION_H
#include "gauss.h"

void fonction(int, int, double tab[N][N], double tab2[N]);

#endif /* FONCTION_H */

