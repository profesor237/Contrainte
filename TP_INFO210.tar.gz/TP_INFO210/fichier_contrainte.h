#ifndef FICHIER_CONTRAINTE_H_INCLUDED
#define FICHIER_CONTRAINTE_H_INCLUDED
#include <string>
#include <stdlib.h>
#include <fstream>
#include "fonction.h"

using namespace std;



void entete()
 {
     cout << " \n";
     cout << "       _______________________________________________________________________________________________________   \n";
     cout << "      *      ___________   ____________     _  ___         _________  ________   ________     __    ______    * \n";
     cout << "      *     |___________|  ||--------||    | | ||\\     || ||-------  |--------|  --------|   //|| |------|    * \n";
     cout << "      *          | |       ||        ||    | | || \\    || ||         |        |         ||     || |      |    * \n";
     cout << "      *          | |       ||________||    | | ||  \\   || ||_______  |        |   ______||     || |      |    * \n";
     cout << "      *          | |       ||              | | ||   \\  || ||-------  |        |  |--------     || |      |    * \n";
     cout << "      *          | |       ||              | | ||    \\ || ||         |        |  ||            || |      |    * \n";
     cout << "      *          |_|       ||              |_| ||     \\|| ||         |________|  ||______      || |______|    * \n";
     cout << "      *_______________________________________________________________________________________________________* \n";
     cout << "      *************|                                                                    |******************** \n";
     cout << "                  *|                      TECHNIQUES D\'OPTIMISATION                     |* \n";
     cout << "                  *|                                                                    |* \n";
     cout << "                  * -------------------------------------------------------------------- * \n";
     cout << "                  ************************************************************************ \n\n";
 }


void fonction_min()
{
    system("CLS");
    entete();
    cout << "             ---------------------------------------------------------------    \n";
    cout << "            |                                                               |    \n";
    cout << "            |          *****************************************            |     \n";
    cout << "            |          *            FONCTIONS MINIMUM         *            |      \n";
    cout << "            |          *****************************************            |        \n";
    cout << "             ---------------------------------------------------------------         \n\n\n";
    int nv, nc;
    double var_fonc[100], nb_op[100], var_con[100][100], p;
    string op[100], vop;
    double tab_final[100][100];
    cout << "VOTRE FONCTION POSSEDE COMBIEN DE VARIABLES ?  "; cin >> nv;
    cout << "_______________________________________________________________________\n\n";
    if(nv<0)
    {
        cout << "\n\n\n\n                              IMPOSSIBLE D\'AVOIR CE NOMBRE DE VARIABLES...\n\n\n";
            system("PAUSE");
            fonction_min();
    }
    cout << " VEUILLEZ ENTRER LES COEFFICIENTS DE CES VARIABLES : \n\n";
    for (int i=0; i<nv; i++)
    {
        double v;
        cout << "       -Entrez le coefficient de  la variable y" << i+1 << " : "; cin >> v;
        var_fonc[i] = v;
    }
    cout << "________________________________________________________________________\n";
    cout << "\nQUEL EST LE NOMBRE DE CONTRAINTES DE CETTE FONCTION : "; cin >> nc;
    if(nc<0)
    {
       cout << "\n\n\n\n                              IMPOSSIBLE D\'AVOIR CE NOMBRE DE CONTRAINTRES...\n\n\n";
            system("PAUSE");
            fonction_min();
    }

   /* else if(nc>3)
    {
        cout << "\n\n\n\n                              IMPOSSIBLE D\'AVOIR CE NOMBRE DE CONTRAINTRES...\n\n\n";
            system("PAUSE");
            fonction_min();
    }*/
    for(int i=0; i<nc; i++)
    {
        cout << "         -Quel est le nombre d'operateurs de la contrainte numero " <<i+1 << " : "; cin >> p;
        if(p!=1 && p!=2)
        {
            cout << "\n\n\n\n                              IMPOSSIBLE D\'AVOIR CE NOMBRE D\'OPERATEURS...\n\n\n";
            system("PAUSE");
            fonction_min();
        }
        nb_op[i] = p;
    }

    cout << "\n\n";
    cout << " *******************************************************************\n";
    cout << " *                                                                 *\n";
    cout << " *     MAINTENANT ENREGISTRONS LES INEQUATIONS DES CONTRAINTES     *\n";
    cout << " *                                                                 *\n";
    cout << " *******************************************************************\n\n\n";
    for(int j=0; j<nc;j++)
    {
        cout << " ENREGISTREMENT DE LA " << j+1 << "eme CONTRAINTE : \n";
        cout << "---------------------------------------------------------------\n\n";
                if (nb_op[j] == 1)
                {
                    cout << " ENTREZ L'OPERATEUR DE LA CONTRAINTE NUMERO " << j+1 << " : "; cin >> vop;
                    if(vop!= ">=" && vop != "<=" )
                    {
                        cout << "\n\n\n\n                              IMPOSSIBLE D\'AVOIR CE TYPE D'OPERATEUR...\n\n\n";
                        system("PAUSE");
                        fonction_min();
                    }
                    op[j] = vop;
                    cout << "\n ENTREZ LES COEFFICIENTS DES VARIABLES DE CES CONTRAINTES : \n";
                    for (int t=0; t<nv; t++)
                    {
                        int n;
                        cout << "          -Coefficient de la variable y " << t+1 << " : "; cin >> n;
                        var_con[j][t] = n;
                    }
                }
                else if(nb_op[j] == 2)
                {
                    cout << " ENTREZ L'OPERATEUR DE LA CONTRAINTE NUMERO " << j+1 << " : "; cin >> vop;
                    if(vop!= ">=" && vop != "<=")
                    {
                        cout << "\n\n\n\n                              IMPOSSIBLE D\'AVOIR CE TYPE D'OPERATEUR...\n\n\n";
                        system("PAUSE");
                        fonction_min();
                    }

                    op[j] = vop;

                    double n, m, t;

                    cout << "\nVEUILLEZ NOUS FOURNIR LES INFORMATIONS SUIVANTES :  \n";
                    cout << "_____________________________________________________________________________\n\n";
                    cout << "            -Entrez la valeur qui vient avant l'operateur : "; cin >> m;
                    var_con[j][0] = m;
                    for (int t=1; t<nv+1; t++)
                    {
                        int n;
                        cout << "         -Coefficient de la variable numero " << t << " : "; cin >> n;
                        var_con[j][t] = n;

                    }
                    cout << "         -Entrez la valeur qui vient apres l'operateur : "; cin >>t;
                    var_con[j][nv+1] = t;

                }

    }
    cout << "__________________________________________________________________________________________________________\n\n\n";
    cout << " *************************************************************************************\n";
    cout << " *                                                                                   *\n";
    cout << " *                  VOICI LA FONCTION QUE VOUS VENEZ D'ENREGISTRER                   *\n";
    cout << " *                                                                                   *\n";
    cout << " *************************************************************************************\n\n";
    cout << "___________________________________________________________________________________________________________\n\n\n";
    cout << "          MIN   F( ";
    for(int i=0; i<nv;i++)
    {
        cout << "y" << i+1 << " ";
    }
    cout << " ) = [";
    for(int i=0; i<nv;i++)
    {
        cout << " +(" << var_fonc[i] <<"y" << i+1 <<")";
    }
    cout << " ]\n\n\n";
    for(int i=0;i<nc;i++)
    {
        cout << "                  |  ";
        if(nb_op[i]==1)
         {
             for(int j=0; j<nv; j++)
            {
                cout <<" + (" <<var_con[i][j] << "y" << i+1<<")";
            }
            cout << op[i] << " 0 \n\n" ;
        }
        else if(nb_op[i] == 2)
        {
            cout << var_con[i][0] << "  " << op[i] <<" ";
            for(int j=1;j<nv+1;j++)
            {
              cout << "+(" << var_con[i][j] <<"y" << j<<")";
            }
              cout <<op[i]<<" " <<  var_con[i][nv+1]<<"\n\n";

        }

    }


    cout << "\n\n\n";
    cout << "____________________________________________________________________________________________________________\n";
    cout << "                       ---------------------------------------------------------------\n";
    cout << "                               FIN DU PROCESSUS D'ENREGISTREMENT DE LA FONCTION       \n";
    cout << "                       ---------------------------------------------------------------\n";
    cout << "_____________________________________________________________________________________________________________\n\n\n";
    cout << " \n\n\n\n\n\n\n";
    cout << "\n\n"; system("PAUSE");
    system("CLS");
    cout << "\n\n\n";
    cout << "********************************************************************\n";
    cout << "*                                                                  *   \n";
    cout << "*     NORMALISATION DE LA FORME DES CONTRAINTES                    *    \n";
    cout << "*                                                                  *     \n";
    cout << "*********************************************************************\n\n\n";
    cout << " LA NORMALISATION ICI CONSISTE A MODIFIER LE SENS DES CONTRAINTES POUR OBTENIR UNE FORME GENERALE DES CONTRAINTES. \n";
    cout << "____________________________________________________________________________________________________\n\n\n";
    cout << " Voici vos contraintes a la forme normalisee : \n\n\n";

    for(int i=0;i<nc;i++)
    {
        cout << "                  |  ";
        if(nb_op[i]==1)
         {
             if(op[i] == "<=")
             {
                 for(int j=0; j<nv; j++)
                 {
                     var_con[i][j] = -1 * var_con[i][j];
                     op[i] = ">=";
                 }
             }
             for(int j=0; j<nv; j++)
            {
                cout <<" + (" <<var_con[i][j] << "y" << i+1<<")";
            }
            cout << op[i] << " 0 \n\n" ;
        }
        else if(nb_op[i] == 2)
        {
            if(op[i] == ">=")
             {
                 for(int j=0; j<nv+3; j++)
                 {
                     var_con[i][j] = -1 * var_con[i][j];
                     op[i] = "<=";
                 }
             }
            cout << var_con[i][0] << "  " << op[i] <<" ";
            for(int j=1;j<nv+1;j++)
            {
              cout << "+(" << var_con[i][j] <<"y" << j<<")";
            }
              cout <<op[i]<<" " <<  var_con[i][nv+1]<<"\n\n";

        }

    }
    cout << "\n\n\n";
    cout << "____________________________________________________________________________________________________________\n";
    cout << "                       ---------------------------------------------------------------\n";
    cout << "                               FIN DU PROCESSUS DE NORMALISATION DES CONTRAINTES      \n";
    cout << "                       ---------------------------------------------------------------\n";
    cout << "_____________________________________________________________________________________________________________\n\n\n";
    cout << " \n\n\n\n\n";
    cout << "\n\n"; system("PAUSE");
    system("CLS");
    cout << "\n\n\n";
    cout << " *********************************************************************\n";
    cout << " *                                                                   * \n";
    cout << " *                 TRANSFORMATION DES CONTRAINTES                    *   \n";
    cout << " *                                                                   * \n";
    cout << " *********************************************************************\n";

    cout << " +POUR LA TRANSFORMATION DES CONTRAINTES, DEUX METHODES S'OFFRENT A NOUS : \n";
    cout << "_________________________________________________________________________________\n\n";
    cout << "               1- Si la contraintre est de forme la Yi>=0  : \n";
    cout << "                    Yi = Xi^2    ou      Yi = exp^(Xi)\n\n";
    cout << "               2- Si la contrainte est sur la forme Ai <= Yi <= Bi : \n";
    cout << "                    Yi = Ai + (Bi - Ai)Sin^2(Xi) \n\n";
    cout << "__________________________________________________________________________________\n\n\n";
    cout << " + PASSONS MAINTENANT LA TRANSFORMATION DES CONTRAINTES : \n";
    cout << "__________________________________________________________________________________\n\n\n\n";
    system("PAUSE");
    cout << " Apres transformaton on obtient l'equation suivante : \n";
    cout << "__________________________________________________________________________________\n\n\n";
        for(int i=0;i<nc;i++)
    {
        cout << "                  |  ";
        if(nb_op[i]==1)
         {
             if(op[i] == "<=")
             {
                 for(int j=0; j<nv; j++)
                 {
                     var_con[i][j] = -1 * var_con[i][j];
                     op[i] = ">=";
                 }
             }
             for(int j=0; j<nv; j++)
            {
                cout <<" + (" <<var_con[i][j] << "y" << j+1<<")";
                tab_final[i][j] = var_con[i][j];
            }
            cout <<" = X" << i+1 << "^2 \n\n" ;
            tab_final[i][nv] = 0.0001; tab_final[i][nv+1] = 0.0001;
        }
        else if(nb_op[i] == 2)
        {
            if(op[i] == ">=")
             {
                 for(int j=0; j<nv+3; j++)
                 {
                     var_con[i][j] = -1 * var_con[i][j];
                     op[i] = "<=";
                 }
             }
             if(var_con[i][0] == -1 && var_con[i][nv+1] == 1)
             {
                 int k(0);
                for(int j=1;j<nv+1;j++)
                {
                   cout << "+(" << var_con[i][j] <<"y" << j+1<<")";
                   tab_final[i][k] = var_con[i][j];
                   k++;
                }
                cout << " = Sin(X" << i+1 << ")\n\n";
                tab_final[i][nv] = 0.0002; tab_final[i][nv+1] = 0.0002;

             }
             else
             {
                 int k(0);
                for(int j=1;j<nv+1;j++)
                {
                    cout << "+(" << var_con[i][j] <<"y" << j<<")";
                    tab_final[i][k] = var_con[i][j];
                    k++;

                }
                cout << " = " << var_con[i][0] << " + (" << var_con[i][nv+1] - var_con[i][0] <<")Sin^2(X" << i+1 << ")\n\n";
                double t =var_con[i][0]; tab_final[i][nv] = t;  double r = var_con[i][nv+1]; tab_final[i][nv+1]  = r;
             }


        }

    }

    /*cout << "\n\n  Nombe d'equations : "  << nc << "\n\n";
    cout << " \n\n Nombre de variables : " << nv << "\n\n";

    cout << " Tableau des coefficients : \n";
    for (int i=0; i<nc; i++)
    {
        for(int j=0; j<nv+2; j++)
        {
            cout << tab_final[i][j] << "\t";
        }
        cout << " \n\n";
    }

    cout << " \n\nTableau des coefficients de la fonction  : \n";
    for(int i=0; i<nv; i++)
    {
        cout << var_fonc[i] << "\t";
    }
    
        **/
   
    if (nc < nv)
    {
        cout << " \n\n";
        cout << "--------------------------------------------------------------------------------------------------------------------\n\n";
        cout << "                  +IMPOSSIBLE DE RESOUDRE CE PROBLEME PAR LA METHODE D'ELIMINATION DES CONTRAINTES         \n\n";
        cout << "  JUSTIFICATIONS :        \n\n";
        cout << "      - Le nombre d'equation de contraintes est inferieur au nombre de variables de la fonction.\n\n";
        cout << "      - Il sera impossible d'exprimer toutes les variables car le systeme d'equation admettra une infinite de solution.\n\n";
        cout << "      - Par consequent, on ne pourra obtenir de bons changements de variables afin d'eliminer les contraintes.\n\n";
        cout << "  N.B : Il s'agit d'une limite de la methode d'elimination des contraintes . \n\n";
        cout << "---------------------------------------------------------------------------------------------------------------------\n\n";
        system("PAUSE");
        fonction_min();
    }
    else if(nc > nv)
    {
        cout << " \n\n";
        cout << "--------------------------------------------------------------------------------------------------------------------\n\n";
        cout << "                    + LA RESOLUTION DE CE SYSTEME SERA COMPLEXE                                                      \n\n";
        cout << "  JUSTIFICATION :  \n\n";
        cout << "         -Le nombre d'equations est superieur au nombre de variabbles \n\n";
        cout << "         -On va tout d'abord resoudre le systeme d'equation a n equations et n variables issu du systeme principal \n\n";
        cout << "         -Ensuite il faudra remplacer la solution dans le reste d'equations pour verifier, ce qui est tres fastidieux \n\n";
        cout << "   NB : Pour la suite, nous allons simplement resoudre le systeme de n equations a n inconnus \n\n";
        cout << "---------------------------------------------------------------------------------------------------------------------\n\n";

    }
    
     fonction(nc,nv+2,tab_final,var_fonc);
    cout << "\n\n\n\n\n";
    cout << "____________________________________________________________________________________________________________\n";
    cout << "                       ---------------------------------------------------------------\n";
    cout << "                                     FIN DU PROCESSUS DE TRANSFORMATION \n";
    cout << "                       ---------------------------------------------------------------\n";
    cout << "_____________________________________________________________________________________________________________\n\n\n";


}


void fonction_max()
{
    system("CLS");
    entete();
    cout << "             ---------------------------------------------------------------    \n";
    cout << "            |                                                               |    \n";
    cout << "            |          *****************************************            |     \n";
    cout << "            |          *            FONCTIONS MAXIMUM          *            |      \n";
    cout << "            |          *****************************************            |        \n";
    cout << "             ---------------------------------------------------------------         \n\n\n";
    int nv, nc;
    double var_fonc[100], nb_op[100], var_con[100][100], p;
    string op[100], vop;
    double tab_final[100][100];
    cout << "VOTRE FONCTION POSSEDE COMBIEN DE VARIABLES ?  "; cin >> nv;
    cout << "_______________________________________________________________________\n\n";
    if(nv<0)
    {
        cout << "\n\n\n\n                              IMPOSSIBLE D\'AVOIR CE NOMBRE DE VARIABLES...\n\n\n";
            system("PAUSE");
            fonction_min();
    }
    cout << " VEUILLEZ ENTRER LES COEFFICIENTS DE CES VARIABLES : \n\n";
    for (int i=0; i<nv; i++)
    {
        double v;
        cout << "       -Entrez le coefficient de  la variable y" << i+1 << " : "; cin >> v;
        var_fonc[i] = v;
    }
    cout << "________________________________________________________________________\n";
    cout << "\nQUEL EST LE NOMBRE DE CONTRAINTES DE CETTE FONCTION : "; cin >> nc;
    if(nc<0)
    {
       cout << "\n\n\n\n                              IMPOSSIBLE D\'AVOIR CE NOMBRE DE CONTRAINTRES...\n\n\n";
            system("PAUSE");
            fonction_min();
    }

   /* else if(nc>3)
    {
        cout << "\n\n\n\n                              IMPOSSIBLE D\'AVOIR CE NOMBRE DE CONTRAINTRES...\n\n\n";
            system("PAUSE");
            fonction_min();
    }*/
    for(int i=0; i<nc; i++)
    {
        cout << "         -Quel est le nombre d'operateurs de la contrainte numero " <<i+1 << " : "; cin >> p;
        if(p!=1 && p!=2)
        {
            cout << "\n\n\n\n                              IMPOSSIBLE D\'AVOIR CE NOMBRE D\'OPERATEURS...\n\n\n";
            system("PAUSE");
            fonction_min();
        }
        nb_op[i] = p;
    }

    cout << "\n\n";
    cout << " *******************************************************************\n";
    cout << " *                                                                 *\n";
    cout << " *     MAINTENANT ENREGISTRONS LES INEQUATIONS DES CONTRAINTES     *\n";
    cout << " *                                                                 *\n";
    cout << " *******************************************************************\n\n\n";
    for(int j=0; j<nc;j++)
    {
        cout << " ENREGISTREMENT DE LA " << j+1 << "eme CONTRAINTE : \n";
        cout << "---------------------------------------------------------------\n\n";
                if (nb_op[j] == 1)
                {
                    cout << " ENTREZ L'OPERATEUR DE LA CONTRAINTE NUMERO " << j+1 << " : "; cin >> vop;
                    if(vop!= ">=" && vop != "<=" )
                    {
                        cout << "\n\n\n\n                              IMPOSSIBLE D\'AVOIR CE TYPE D'OPERATEUR...\n\n\n";
                        system("PAUSE");
                        fonction_min();
                    }
                    op[j] = vop;
                    cout << "\n ENTREZ LES COEFFICIENTS DES VARIABLES DE CES CONTRAINTES : \n";
                    for (int t=0; t<nv; t++)
                    {
                        int n;
                        cout << "          -Coefficient de la variable y " << t+1 << " : "; cin >> n;
                        var_con[j][t] = n;
                    }
                }
                else if(nb_op[j] == 2)
                {
                    cout << " ENTREZ L'OPERATEUR DE LA CONTRAINTE NUMERO " << j+1 << " : "; cin >> vop;
                    if(vop!= ">=" && vop != "<=")
                    {
                        cout << "\n\n\n\n                              IMPOSSIBLE D\'AVOIR CE TYPE D'OPERATEUR...\n\n\n";
                        system("PAUSE");
                        fonction_min();
                    }

                    op[j] = vop;

                    double n, m, t;

                    cout << "\nVEUILLEZ NOUS FOURNIR LES INFORMATIONS SUIVANTES :  \n";
                    cout << "_____________________________________________________________________________\n\n";
                    cout << "            -Entrez la valeur qui vient avant l'operateur : "; cin >> m;
                    var_con[j][0] = m;
                    for (int t=1; t<nv+1; t++)
                    {
                        int n;
                        cout << "         -Coefficient de la variable numero " << t << " : "; cin >> n;
                        var_con[j][t] = n;

                    }
                    cout << "         -Entrez la valeur qui vient apres l'operateur : "; cin >>t;
                    var_con[j][nv+1] = t;

                }

    }
    cout << "__________________________________________________________________________________________________________\n\n\n";
    cout << " *************************************************************************************\n";
    cout << " *                                                                                   *\n";
    cout << " *                  VOICI LA FONCTION QUE VOUS VENEZ D'ENREGISTRER                   *\n";
    cout << " *                                                                                   *\n";
    cout << " *************************************************************************************\n\n";
    cout << "___________________________________________________________________________________________________________\n\n\n";
    cout << "          MAX F( ";
    for(int i=0; i<nv;i++)
    {
        cout << "y" << i+1 << " ";
    }
    cout << " ) = [";
    for(int i=0; i<nv;i++)
    {
        cout << " +(" << var_fonc[i] <<"y" << i+1 <<")";
    }
    cout << " ]\n\n\n";
    for(int i=0;i<nc;i++)
    {
        cout << "                  |  ";
        if(nb_op[i]==1)
         {
             for(int j=0; j<nv; j++)
            {
                cout <<" + (" <<var_con[i][j] << "y" << i+1<<")";
            }
            cout << op[i] << " 0 \n\n" ;
        }
        else if(nb_op[i] == 2)
        {
            cout << var_con[i][0] << "  " << op[i] <<" ";
            for(int j=1;j<nv+1;j++)
            {
              cout << "+(" << var_con[i][j] <<"y" << j<<")";
            }
              cout <<op[i]<<" " <<  var_con[i][nv+1]<<"\n\n";

        }

    }


    cout << "\n\n\n";
    cout << "____________________________________________________________________________________________________________\n";
    cout << "                       ---------------------------------------------------------------\n";
    cout << "                               FIN DU PROCESSUS D'ENREGISTREMENT DE LA FONCTION       \n";
    cout << "                       ---------------------------------------------------------------\n";
    cout << "_____________________________________________________________________________________________________________\n\n\n";
    cout << " \n\n\n\n\n\n\n";
    cout << "\n\n"; system("PAUSE");
    system("CLS");
    cout << "\n\n\n";
    cout << "********************************************************************\n";
    cout << "*                                                                  *   \n";
    cout << "*     NORMALISATION DE LA FORME DES CONTRAINTES                    *    \n";
    cout << "*                                                                  *     \n";
    cout << "*********************************************************************\n\n\n";
    cout << " LA NORMALISATION ICI CONSISTE A MODIFIER LE SENS DES CONTRAINTES POUR OBTENIR UNE FORME GENERALE DES CONTRAINTES. \n";
    cout << "____________________________________________________________________________________________________\n\n\n";
    cout << " Voici vos contraintes a la forme normalisee : \n\n\n";

    for(int i=0;i<nc;i++)
    {
        cout << "                  |  ";
        if(nb_op[i]==1)
         {
             if(op[i] == "<=")
             {
                 for(int j=0; j<nv; j++)
                 {
                     var_con[i][j] = -1 * var_con[i][j];
                     op[i] = ">=";
                 }
             }
             for(int j=0; j<nv; j++)
            {
                cout <<" + (" <<var_con[i][j] << "y" << i+1<<")";
            }
            cout << op[i] << " 0 \n\n" ;
        }
        else if(nb_op[i] == 2)
        {
            if(op[i] == ">=")
             {
                 for(int j=0; j<nv+3; j++)
                 {
                     var_con[i][j] = -1 * var_con[i][j];
                     op[i] = "<=";
                 }
             }
            cout << var_con[i][0] << "  " << op[i] <<" ";
            for(int j=1;j<nv+1;j++)
            {
              cout << "+(" << var_con[i][j] <<"y" << j<<")";
            }
              cout <<op[i]<<" " <<  var_con[i][nv+1]<<"\n\n";

        }

    }
    cout << "\n\n\n";
    cout << "____________________________________________________________________________________________________________\n";
    cout << "                       ---------------------------------------------------------------\n";
    cout << "                               FIN DU PROCESSUS DE NORMALISATION DES CONTRAINTES      \n";
    cout << "                       ---------------------------------------------------------------\n";
    cout << "_____________________________________________________________________________________________________________\n\n\n";
    cout << " \n\n\n\n\n";
    cout << "\n\n"; system("PAUSE");
    system("CLS");
    cout << "\n\n\n";
    cout << " *********************************************************************\n";
    cout << " *                                                                   * \n";
    cout << " *                 TRANSFORMATION DES CONTRAINTES                    *   \n";
    cout << " *                                                                   * \n";
    cout << " *********************************************************************\n";

    cout << " +POUR LA TRANSFORMATION DES CONTRAINTES, DEUX METHODES S'OFFRENT A NOUS : \n";
    cout << "_________________________________________________________________________________\n\n";
    cout << "               1- Si la contraintre est de forme la Yi>=0  : \n";
    cout << "                    Yi = Xi^2    ou      Yi = exp^(Xi)\n\n";
    cout << "               2- Si la contrainte est sur la forme Ai <= Yi <= Bi : \n";
    cout << "                    Yi = Ai + (Bi - Ai)Sin^2(Xi) \n\n";
    cout << "__________________________________________________________________________________\n\n\n";
    cout << " + PASSONS MAINTENANT LA TRANSFORMATION DES CONTRAINTES : \n";
    cout << "__________________________________________________________________________________\n\n\n\n";
    system("PAUSE");
    cout << " Apres transformaton on obtient l'equation suivante : \n";
    cout << "__________________________________________________________________________________\n\n\n";
        for(int i=0;i<nc;i++)
    {
        cout << "                  |  ";
        if(nb_op[i]==1)
         {
             if(op[i] == "<=")
             {
                 for(int j=0; j<nv; j++)
                 {
                     var_con[i][j] = -1 * var_con[i][j];
                     op[i] = ">=";
                 }
             }
             for(int j=0; j<nv; j++)
            {
                cout <<" + (" <<var_con[i][j] << "y" << j+1<<")";
                tab_final[i][j] = var_con[i][j];
            }
            cout <<" = X" << i+1 << "^2 \n\n" ;
            tab_final[i][nv] = 0.0001; tab_final[i][nv+1] = 0.0001;
        }
        else if(nb_op[i] == 2)
        {
            if(op[i] == ">=")
             {
                 for(int j=0; j<nv+3; j++)
                 {
                     var_con[i][j] = -1 * var_con[i][j];
                     op[i] = "<=";
                 }
             }
             if(var_con[i][0] == -1 && var_con[i][nv+1] == 1)
             {
                 int k(0);
                for(int j=1;j<nv+1;j++)
                {
                   cout << "+(" << var_con[i][j] <<"y" << j+1<<")";
                   tab_final[i][k] = var_con[i][j];
                   k++;
                }
                cout << " = Sin(X" << i+1 << ")\n\n";
                tab_final[i][nv] = 0.0002; tab_final[i][nv+1] = 0.0002;

             }
             else
             {
                 int k(0);
                for(int j=1;j<nv+1;j++)
                {
                    cout << "+(" << var_con[i][j] <<"y" << j<<")";
                    tab_final[i][k] = var_con[i][j];
                    k++;

                }
                cout << " = " << var_con[i][0] << " + (" << var_con[i][nv+1] - var_con[i][0] <<")Sin^2(X" << i+1 << ")\n\n";
                double t =var_con[i][0]; tab_final[i][nv] = t;  double r = var_con[i][nv+1]; tab_final[i][nv+1]  = r;
             }


        }

    }

    /*cout << "\n\n  Nombe d'equations : "  << nc << "\n\n";
    cout << " \n\n Nombre de variables : " << nv << "\n\n";

    cout << " Tableau des coefficients : \n";
    for (int i=0; i<nc; i++)
    {
        for(int j=0; j<nv+2; j++)
        {
            cout << tab_final[i][j] << "\t";
        }
        cout << " \n\n";
    }

    cout << " \n\nTableau des coefficients de la fonction  : \n";
    for(int i=0; i<nv; i++)
    {
        cout << var_fonc[i] << "\t";
    }
    
        **/
   
    if (nc < nv)
    {
        cout << " \n\n";
        cout << "--------------------------------------------------------------------------------------------------------------------\n\n";
        cout << "                  +IMPOSSIBLE DE RESOUDRE CE PROBLEME PAR LA METHODE D'ELIMINATION DES CONTRAINTES         \n\n";
        cout << "  JUSTIFICATIONS :        \n\n";
        cout << "      - Le nombre d'equation de contraintes est inferieur au nombre de variables de la fonction.\n\n";
        cout << "      - Il sera impossible d'exprimer toutes les variables car le systeme d'equation admettra une infinite de solution.\n\n";
        cout << "      - Par consequent, on ne pourra obtenir de bons changements de variables afin d'eliminer les contraintes.\n\n";
        cout << "  N.B : Il s'agit d'une limite de la methode d'elimination des contraintes . \n\n";
        cout << "---------------------------------------------------------------------------------------------------------------------\n\n";
        system("PAUSE");
        fonction_min();
    }
    else if(nc > nv)
    {
        cout << " \n\n";
        cout << "--------------------------------------------------------------------------------------------------------------------\n\n";
        cout << "                    + LA RESOLUTION DE CE SYSTEME SERA COMPLEXE                                                      \n\n";
        cout << "  JUSTIFICATION :  \n\n";
        cout << "         -Le nombre d'equations est superieur au nombre de variabbles \n\n";
        cout << "         -On va tout d'abord resoudre le systeme d'equation a n equations et n variables issu du systeme principal \n\n";
        cout << "         -Ensuite il faudra remplacer la solution dans le reste d'equations pour verifier, ce qui est tres fastidieux \n\n";
        cout << "   NB : Pour la suite, nous allons simplement resoudre le systeme de n equations a n inconnus \n\n";
        cout << "---------------------------------------------------------------------------------------------------------------------\n\n";

    }
    
     fonction(nc,nv+2,tab_final,var_fonc);
    cout << "\n\n\n\n\n";
    cout << "____________________________________________________________________________________________________________\n";
    cout << "                       ---------------------------------------------------------------\n";
    cout << "                                     FIN DU PROCESSUS DE TRANSFORMATION \n";
    cout << "                       ---------------------------------------------------------------\n";
    cout << "_____________________________________________________________________________________________________________\n\n\n";


}

#endif // FICHIER_CONTRAINTE_H_INCLUDED
