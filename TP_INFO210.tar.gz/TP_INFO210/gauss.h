#ifndef _GAUSS_H
#define _GAUSS_H
#include <iostream> 
#include <string>
#include <sstream>
#include <fstream>


#define N 100 // dimension de la Matrice

class Matrice
{
	private:
		double mat[N][N]; 
	public:
		Matrice();
                void saisie(int, double tab[N][N]);
		void gaussifier(std::string*, std::string*,int);
		//void afficher();
		void afficher(std::string* b, std::string* x, int,double *tab,int);
                std::string convertion(double);
             
};

#endif
