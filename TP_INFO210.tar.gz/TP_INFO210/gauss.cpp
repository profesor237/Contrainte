#include <iostream>
#include "gauss.h"



Matrice::Matrice()
{
    for(int i=0;i<N;i++){
        for(int j=0;j<N;j++ ){
            mat[i][j] = 0;
        }
    }
}

void Matrice::saisie(int n, double tab[N][N]){ // insere les coefficient de la matrice
    
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++ ){
            mat[i][j] = tab[i][j];
        }
    }    
}

std::string Matrice::convertion(double x){
    std::stringstream ss;
    ss << x ;
    std::string str = ss.str();    
    return str;
}

/**void Matrice::afficher()
{
	// simplement pour afficher la Matrice d'origine
	std::cout << std::endl;
	int i,j;
	for(i=0;i<N;i++)
	{
		for(j=0;j<N;j++)
		{
			std::cout << mat[i][j] << "\t";
		}
		std::cout << std::endl;
	}
}
 **/
   

void Matrice::afficher(std::string* b, std::string* x, int n, double tab[N], int h)
{
	// on affiche la Matrice d'origine (mat) puis la Matrice colonne contenant les résultats (x1, ..., xn)
	// enfin on affiche la Matrice B modifiée
	int i,j;
        std::cout <<"\t\t+------------------------------------------------------+\t\t\n";
        std::cout <<"\t\t+--------------Expression des variables----------------+\t\t\n";
        std::cout <<"\t\t+------------------------------------------------------+\t\t\n";
        std::cout << "\n";
	for(i=0;i<n;i++)
	{   
            int r = i+1;
            std::cout << "\t\tx" << r << " = " << x[i] << "\n";
	}
        
        std::cout <<"\n\t\t+------------------------------------------------------+\t\t\n";
        std::cout <<"\t\t+------Expression de la fonction sans contraintes------+\t\t\n";
        std::cout <<"\t\t+------------------------------------------------------+\t\t\n\n";
        
        if(h==0){
            std::cout <<"\t\tF(X) = ";
            for(i=0;i<n;i++)
            {        
                std::cout << tab[i] << "(" << x[i] << ")";
                if(i==n-1) break;
                std::cout << "+";            
            }
            std::cout << "\n";
        }
        else{
            if(h>0){
                std::cout << "\t\tSi ces variables verifient les "<< h << " dernieres equations, alors :\n\n";
                std::cout <<"\t\tF(X) = ";
                for(i=0;i<n;i++)
                {        
                    std::cout << tab[i] << "(" << x[i] << ")";
                    if(i==n-1) break;
                    std::cout << "+";            
                }
                std::cout << "\n";

                std::cout <<"\n\t\tDans le cas contraire, F(X) n'admet pas d'expressions sans contraintes.\n";
            }
        }
        
}
void Matrice::gaussifier(std::string* b, std::string* X, int n)
{
	// Résolution du système par la méthode de gauss
	int i,j,k;
	double coef;
	double temp;
        std::string tmp;
        std::string m_coef,m = " - ", p = " + ", e = " ",u1="(",u2=")";
        
	
	// triangularisation de la Matrice
	for(k=0;k<n-1;k++)
	{
	
		for(i=k+1;i<n;i++)
		{
		
			if(mat[k][k]==0)
			{
				// On inverse les deux lignes ( i et k ) de la  Matrice mat
				for(int l=0;l<n;l++)
				{
					temp=mat[i][l];
					mat[i][l]=mat[k][l];
					mat[k][l]=temp;
				}
				// et on fait de même pour b
                                tmp = b[i];
				b[i] = b[k];
				b[k] = tmp;
			}
		
			coef = mat[i][k] / mat[k][k];
			
			// on remplit la partie inférieure de la Matrice mat avec des 0
			mat[i][k] = 0;
			
			// On applique le coef sur la ligne i de la Matrice mat
			for(j=k+1;j<n;j++)
			{
				mat[i][j] = mat[i][j] - coef * mat[k][j];
			}
                        
			// idem pour b                        
                        m_coef = convertion(coef);
                        if(coef > 0){
                            b[i] = b[i] + m + m_coef + b[k];
                        }
                        else{
                           b[i] = b[i] + p + m_coef + b[k];
                        }
                        if(coef == 0) b[i] = b[i];
                        
		}
	}
	
	std::string somme;
	// résolution du système
	for(i=n-1;i>=0;i--)
	{
		for(j=n-1;j>=i;j--)
		{
			somme="";
			for(k=j+1;k<n;k++)
			{
                            double a = mat[i][k];
                            std::string q = convertion(a);
                            somme = somme + q + X[k] + e;
				//std::cout << "i : " << i << " j : " << j << " k : " << k << " somme : " << somme << std::endl;
			}
                        double a = mat[i][j];
                        double qt = (1.00/a);
                        std::string quot = convertion(qt);
                        if(somme.size()){
                            X[i] = quot + u1 + b[i] + m + somme + u2;
			}
                        else{
                            X[i] = quot + u1 + b[i] + u2; 
                        }
		}
	}

}

